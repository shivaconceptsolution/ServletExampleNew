package scs;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.SI;
/**
 * Servlet implementation class SISer
 */
@WebServlet("/SISer")
public class SISer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SISer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.write("<html>");
		out.write("<head>");
		out.write("</head>");
		out.write("<body>");
		out.write("<h1>SI Program</h1>");
		out.write("<form action='' method='post'>");
		out.write("<input type='text' name='txtp' placeholder='Enter p' /> <br>");
		out.write("<input type='text' name='txtr' placeholder='Enter r' /><br>");
		out.write("<input type='text' name='txtt' placeholder='Enter t' /><br>");
		out.write("<input type='submit'  value='calculate' />");
		out.write("</form>");
		
		
		out.write("</body>");
		
		if(request.getParameter("q")!=null)
		{
			out.write("Result is "+request.getParameter("q"));
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SI obj = new SI();
		
	    float  p = Float.parseFloat(request.getParameter("txtp"));
	    float  r = Float.parseFloat(request.getParameter("txtr"));
	    float  t = Float.parseFloat(request.getParameter("txtt"));
	    obj.setP(p);
	    obj.setR(r);
	    obj.setT(t);
	    double si;
	    if(request.getParameter("interest").equals("si"))
	    {
	    si = (obj.getP()*obj.getR()*obj.getT())/100;
	    }
	    else
	    {
	    si = p*Math.pow(1+((r/100)/12),12*t)-p;
	    }
	   // PrintWriter out = response.getWriter();
	   // out.write("Result is "+si);
	   response.sendRedirect("Dropdownlist.jsp?q="+si);
	    
	}

}
